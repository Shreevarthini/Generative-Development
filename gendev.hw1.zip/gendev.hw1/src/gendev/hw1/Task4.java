package gendev.hw1;

public class Task4 {
	public static String instance = "task4_Instances/instance.xmi";

	public static void main(String[] args) {
		System.out.println("Creating and saving instance to file " + instance);

		// TODO implement your code here
	}

}
